from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

keyboard = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton(
                text="Developer",
                url="https://t.me/LegendBot_Owner",
            ),
            InlineKeyboardButton(
                text="About Me",
                url="https://t.me/LegendBot_AI/476",
            ),
        ],
    ]
)
