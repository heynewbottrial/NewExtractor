api_id = 17864183
api_hash = "b7cf3765dcf2e2781c98fc57f9f87a5b"
bot_token = "6752335890:AAH0Dav1-QtqmsMLiaM2ho9MEcpuTRJSNdg"
auth_users = "6629551092, 1318247204"
sudo_users = [int(num) for num in auth_users.split(",")]
osowner_users = "6629551092"
owner_users = [int(num) for num in osowner_users.split(",")]
